"""
Payment router — handles Telebirr payment webhooks and manual verification.
"""

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.services.payment_repository import PaymentRepository
from app.services.payment_service import telebirr_service
from app.services.telegram_service import telegram_service
from app.services.user_service import UserRepository

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/telebirr-webhook")
async def telebirr_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    """
    Receives Telebirr payment confirmation callbacks.
    Telebirr POSTs a signed JSON payload when payment is completed.
    """
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info(f"Telebirr webhook received: {json.dumps(payload)[:500]}")

    # Verify signature
    if not telebirr_service.verify_webhook_signature(dict(payload)):
        logger.warning("Telebirr webhook signature verification failed")
        raise HTTPException(status_code=403, detail="Invalid signature")

    # Extract fields (Telebirr payload format)
    trade_status = payload.get("tradeStatus") or payload.get("status", "")
    order_id = payload.get("outTradeNo") or payload.get("orderId", "")
    transaction_id = payload.get("tradeNo") or payload.get("transactionId", "")

    if trade_status not in ("SUCCESS", "TRADE_SUCCESS", "success"):
        logger.info(f"Payment not successful: status={trade_status}, order={order_id}")
        return {"result": "noted", "status": trade_status}

    if not order_id:
        raise HTTPException(status_code=400, detail="Missing order ID")

    # Process payment
    await _activate_payment(db, order_id, transaction_id, json.dumps(payload))
    return {"result": "success"}


@router.post("/manual-verify")
async def manual_verify(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Endpoint for admin to manually verify a payment by order_id.
    Used when Telebirr webhook is not available in development.
    """
    from app.core.config import settings

    body = await request.json()
    if body.get("admin_secret") != settings.ADMIN_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")

    order_id = body.get("order_id")
    transaction_id = body.get("transaction_id", "MANUAL_VERIFY")

    if not order_id:
        raise HTTPException(status_code=400, detail="order_id required")

    result = await _activate_payment(db, order_id, transaction_id, json.dumps(body))
    return result


async def _activate_payment(db: AsyncSession, order_id: str, transaction_id: str, raw_payload: str) -> dict:
    """Shared logic: mark payment completed + activate subscription."""
    payment_repo = PaymentRepository(db)
    user_repo = UserRepository(db)

    payment = await payment_repo.get_by_order_id(order_id)
    if not payment:
        logger.warning(f"Payment not found for order_id: {order_id}")
        return {"result": "not_found"}

    if payment.status.value == "completed":
        logger.info(f"Payment {order_id} already completed — idempotent return")
        return {"result": "already_completed"}

    # Mark payment complete
    await payment_repo.mark_completed(order_id, transaction_id, raw_payload)

    # Activate user subscription
    user_id = payment.user_id
    user = await user_repo.activate_subscription(user_id)

    if user:
        expiry_str = user.subscription_expiry.strftime("%d %b %Y") if user.subscription_expiry else "N/A"
        await telegram_service.send_message(
            user_id,
            f"🎉 <b>Payment confirmed!</b>\n\n"
            f"Your NutriScan AI subscription is now <b>active</b>.\n"
            f"Valid until: <b>{expiry_str}</b>\n\n"
            f"📸 Send a food photo to start scanning!",
        )
        logger.info(f"Subscription activated for user {user_id}, expires {expiry_str}")
        return {"result": "success", "user_id": user_id, "expires": expiry_str}

    return {"result": "error", "message": "User not found"}
