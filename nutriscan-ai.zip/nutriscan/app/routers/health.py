"""Health check router."""

from fastapi import APIRouter
from sqlalchemy import text

router = APIRouter()


@router.get("")
@router.get("/")
async def health():
    return {"status": "ok", "service": "NutriScan AI"}


@router.get("/db")
async def health_db():
    from app.core.database import engine
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        return {"status": "error", "database": str(e)}
