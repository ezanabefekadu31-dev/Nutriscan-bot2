"""
Telegram webhook router — receives and validates Telegram updates.
"""

import hashlib
import hmac
import logging

from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.services.message_handler import MessageHandler

logger = logging.getLogger(__name__)
router = APIRouter()


def verify_telegram_secret(x_telegram_bot_api_secret_token: str = Header(default="")) -> bool:
    """Validate the secret token Telegram sends in the header."""
    if not settings.TELEGRAM_WEBHOOK_SECRET:
        return True  # Skip validation if not configured
    if x_telegram_bot_api_secret_token != settings.TELEGRAM_WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Invalid webhook secret")
    return True


@router.post("/telegram")
async def telegram_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    _: bool = Depends(verify_telegram_secret),
):
    """Main Telegram webhook endpoint — processes all bot updates."""
    try:
        update = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    handler = MessageHandler(db)

    if "message" in update:
        background_tasks.add_task(_safe_handle, handler.handle_message, update["message"])
    elif "callback_query" in update:
        background_tasks.add_task(_safe_handle, handler.handle_callback, update["callback_query"])
    else:
        logger.debug(f"Unhandled update type: {list(update.keys())}")

    # Always return 200 quickly — processing happens in background
    return {"ok": True}


async def _safe_handle(handler_fn, data: dict):
    """Wrap handler to catch and log exceptions without crashing the worker."""
    try:
        await handler_fn(data)
    except Exception as e:
        logger.exception(f"Error in handler {handler_fn.__name__}: {e}")
