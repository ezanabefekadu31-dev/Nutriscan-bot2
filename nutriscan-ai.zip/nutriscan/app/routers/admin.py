"""
Admin router — protected management endpoints.
Secured with ADMIN_SECRET header.
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.services.user_service import UserRepository

logger = logging.getLogger(__name__)
router = APIRouter()


def require_admin(x_admin_secret: str = Header(...)):
    if x_admin_secret != settings.ADMIN_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")


class ActivateSubscriptionRequest(BaseModel):
    user_id: int
    days: Optional[int] = None


@router.get("/stats", dependencies=[Depends(require_admin)])
async def get_stats(db: AsyncSession = Depends(get_db)):
    """Return high-level user and subscription stats."""
    user_repo = UserRepository(db)
    stats = await user_repo.get_stats()
    return stats


@router.post("/activate", dependencies=[Depends(require_admin)])
async def activate_subscription(
    body: ActivateSubscriptionRequest,
    db: AsyncSession = Depends(get_db),
):
    """Manually activate or extend a user's subscription."""
    from datetime import timedelta, datetime
    user_repo = UserRepository(db)

    days = body.days or settings.SUBSCRIPTION_DAYS
    user = await user_repo.get(body.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user = await user_repo.activate_subscription(body.user_id)

    from app.services.telegram_service import telegram_service
    await telegram_service.send_message(
        body.user_id,
        f"✅ Your NutriScan AI subscription has been manually activated by admin.\n"
        f"Valid until: <b>{user.subscription_expiry.strftime('%d %b %Y')}</b>",
    )

    return {
        "user_id": body.user_id,
        "status": "activated",
        "expires": user.subscription_expiry.isoformat(),
    }


@router.post("/set-webhook", dependencies=[Depends(require_admin)])
async def set_webhook(url: str):
    """Re-register Telegram webhook."""
    from app.services.telegram_service import telegram_service
    success = await telegram_service.set_webhook(url)
    return {"ok": success, "webhook_url": f"{url}/webhook/telegram"}
