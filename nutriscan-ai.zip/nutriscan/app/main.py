"""
NutriScan AI - Telegram Bot Backend
FastAPI application with webhook handlers for Telegram, payment, and subscription management.
"""

import logging
import sys
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

from app.core.config import settings
from app.core.database import init_db
from app.routers import telegram, payment, health, admin
from app.services.telegram_service import telegram_service

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown lifecycle management."""
    logger.info("🚀 NutriScan AI starting up...")
    
    # Initialize database
    await init_db()
    logger.info("✅ Database initialized")
    
    # Register Telegram webhook
    if settings.WEBHOOK_URL:
        success = await telegram_service.set_webhook(settings.WEBHOOK_URL)
        if success:
            logger.info(f"✅ Telegram webhook registered: {settings.WEBHOOK_URL}")
        else:
            logger.warning("⚠️  Failed to register Telegram webhook")
    
    yield
    
    # Cleanup
    logger.info("👋 NutriScan AI shutting down...")
    await telegram_service.close()


app = FastAPI(
    title="NutriScan AI",
    description="AI-powered nutrition analysis Telegram bot with subscription management",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
)

# Security middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, prefix="/health", tags=["Health"])
app.include_router(telegram.router, prefix="/webhook", tags=["Telegram"])
app.include_router(payment.router, prefix="/payment", tags=["Payment"])
app.include_router(admin.router, prefix="/admin", tags=["Admin"])


@app.get("/")
async def root():
    return {
        "service": "NutriScan AI",
        "status": "operational",
        "version": "1.0.0",
    }
