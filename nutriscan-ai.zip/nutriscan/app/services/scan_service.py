"""
ScanRepository — persists and queries nutrition scan history.
"""

import logging
from typing import Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.scan_history import ScanHistory, ScanType

logger = logging.getLogger(__name__)


class ScanRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def save_scan(
        self,
        user_id: int,
        nutrition: dict,
        scan_type: ScanType = ScanType.IMAGE,
        raw_response: Optional[str] = None,
    ) -> ScanHistory:
        scan = ScanHistory(
            user_id=user_id,
            scan_type=scan_type,
            food_name=nutrition.get("food_name"),
            barcode_value=nutrition.get("barcode"),
            calories=nutrition.get("calories"),
            protein_g=nutrition.get("protein_g"),
            carbs_g=nutrition.get("carbs_g"),
            fat_g=nutrition.get("fat_g"),
            fiber_g=nutrition.get("fiber_g"),
            sugar_g=nutrition.get("sugar_g"),
            sodium_mg=nutrition.get("sodium_mg"),
            serving_size=nutrition.get("serving_size"),
            confidence=nutrition.get("confidence"),
            raw_ai_response=raw_response,
        )
        self.db.add(scan)
        await self.db.flush()
        return scan

    async def get_user_history(self, user_id: int, limit: int = 10) -> list[ScanHistory]:
        result = await self.db.execute(
            select(ScanHistory)
            .where(ScanHistory.user_id == user_id)
            .order_by(ScanHistory.created_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_daily_totals(self, user_id: int) -> dict:
        from datetime import date
        from sqlalchemy import cast, Date

        today = date.today()
        result = await self.db.execute(
            select(
                func.sum(ScanHistory.calories).label("calories"),
                func.sum(ScanHistory.protein_g).label("protein_g"),
                func.sum(ScanHistory.carbs_g).label("carbs_g"),
                func.sum(ScanHistory.fat_g).label("fat_g"),
            ).where(
                ScanHistory.user_id == user_id,
                cast(ScanHistory.created_at, Date) == today,
            )
        )
        row = result.one()
        return {
            "calories": round(row.calories or 0, 1),
            "protein_g": round(row.protein_g or 0, 1),
            "carbs_g": round(row.carbs_g or 0, 1),
            "fat_g": round(row.fat_g or 0, 1),
            "date": today.isoformat(),
        }
