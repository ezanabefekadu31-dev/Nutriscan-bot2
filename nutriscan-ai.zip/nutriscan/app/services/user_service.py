"""
UserRepository — all database operations related to users and subscriptions.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.user import User, SubscriptionStatus

logger = logging.getLogger(__name__)


class UserRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_or_create(
        self,
        user_id: int,
        username: Optional[str] = None,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
    ) -> tuple[User, bool]:
        """Fetch existing user or create a new one. Returns (user, created)."""
        result = await self.db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()

        if user:
            # Refresh profile info
            user.username = username or user.username
            user.first_name = first_name or user.first_name
            user.last_name = last_name or user.last_name
            user.last_active = datetime.utcnow()
            return user, False

        user = User(
            id=user_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            subscription_status=SubscriptionStatus.TRIAL,
            free_scans_used=0,
            last_active=datetime.utcnow(),
        )
        self.db.add(user)
        await self.db.flush()
        logger.info(f"New user created: {user_id} ({first_name})")
        return user, True

    async def get(self, user_id: int) -> Optional[User]:
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def check_and_expire(self, user: User) -> bool:
        """
        Check if the subscription has expired and deactivate if so.
        Returns True if user can scan (active sub or free trial remaining).
        """
        if user.subscription_status == SubscriptionStatus.ACTIVE:
            if user.subscription_expiry and user.subscription_expiry <= datetime.utcnow():
                user.subscription_status = SubscriptionStatus.INACTIVE
                await self.db.flush()
                logger.info(f"Subscription expired for user {user.id}")
                return user.has_free_scans  # fall back to trial if scans remain
            return True

        return user.has_free_scans

    async def increment_free_scan(self, user: User):
        user.free_scans_used += 1
        await self.db.flush()

    async def activate_subscription(self, user_id: int) -> Optional[User]:
        """Activate subscription for 30 days from now."""
        user = await self.get(user_id)
        if not user:
            logger.warning(f"activate_subscription: user {user_id} not found")
            return None

        user.subscription_status = SubscriptionStatus.ACTIVE
        user.subscription_expiry = datetime.utcnow() + timedelta(days=settings.SUBSCRIPTION_DAYS)
        await self.db.flush()
        logger.info(f"Subscription activated for user {user_id} until {user.subscription_expiry}")
        return user

    async def get_stats(self) -> dict:
        from sqlalchemy import func
        total = await self.db.scalar(select(func.count(User.id)))
        active = await self.db.scalar(
            select(func.count(User.id)).where(
                User.subscription_status == SubscriptionStatus.ACTIVE
            )
        )
        return {"total_users": total, "active_subscribers": active}
