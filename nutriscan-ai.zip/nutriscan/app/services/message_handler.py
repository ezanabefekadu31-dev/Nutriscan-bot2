"""
MessageHandler — central dispatcher for all incoming Telegram messages.
Handles the full lifecycle: auth check → image detection → AI analysis → response.
"""

import logging
import re
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.scan_history import ScanType
from app.services.barcode_service import barcode_service
from app.services.nutrition_ai_service import nutrition_ai_service
from app.services.payment_service import telebirr_service
from app.services.payment_repository import PaymentRepository
from app.services.scan_service import ScanRepository
from app.services.telegram_service import telegram_service
from app.services.user_service import UserRepository

logger = logging.getLogger(__name__)

COMMANDS = {
    "/start": "send_welcome",
    "/help": "send_help",
    "/status": "send_status",
    "/history": "send_history",
    "/today": "send_daily_totals",
    "/subscribe": "send_payment",
}


class MessageHandler:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.user_repo = UserRepository(db)
        self.scan_repo = ScanRepository(db)
        self.payment_repo = PaymentRepository(db)

    # ── Entry point ────────────────────────────────────────────────────────────

    async def handle_message(self, message: dict):
        chat_id = message["chat"]["id"]
        from_user = message.get("from", {})
        user_id = from_user.get("id", chat_id)

        # Upsert user
        user, is_new = await self.user_repo.get_or_create(
            user_id=user_id,
            username=from_user.get("username"),
            first_name=from_user.get("first_name"),
            last_name=from_user.get("last_name"),
        )

        if is_new:
            await telegram_service.send_welcome(
                chat_id, user.display_name, settings.FREE_TRIAL_SCANS
            )
            return

        # Route by message type
        text = message.get("text", "").strip()
        photo = message.get("photo")
        document = message.get("document")

        if text.startswith("/"):
            await self._handle_command(text, chat_id, user_id, message)
        elif photo or document:
            await self._handle_image(message, chat_id, user, photo, document)
        elif text:
            await self._handle_text(text, chat_id, user)
        else:
            await telegram_service.send_message(
                chat_id,
                "📸 Send me a food photo or barcode image to analyse nutrition.\n"
                "Or type the food name for a text-based lookup!",
            )

    async def handle_callback(self, callback: dict):
        """Handle inline keyboard button presses."""
        query_id = callback["id"]
        chat_id = callback["message"]["chat"]["id"]
        user_id = callback["from"]["id"]
        data = callback.get("data", "")

        await self._answer_callback(query_id)

        if data.startswith("verify_payment:"):
            await self._handle_payment_verification(chat_id, user_id)
        elif data == "help":
            await self._send_help(chat_id)
        elif data == "subscribe":
            await self._initiate_payment(chat_id, user_id)

    # ── Command handlers ───────────────────────────────────────────────────────

    async def _handle_command(self, text: str, chat_id: int, user_id: int, message: dict):
        cmd = text.split()[0].lower()

        if cmd == "/start":
            user = await self.user_repo.get(user_id)
            if user:
                await telegram_service.send_welcome(
                    chat_id,
                    user.display_name,
                    max(0, settings.FREE_TRIAL_SCANS - user.free_scans_used),
                )
        elif cmd == "/help":
            await self._send_help(chat_id)
        elif cmd == "/status":
            await self._send_status(chat_id, user_id)
        elif cmd == "/history":
            await self._send_history(chat_id, user_id)
        elif cmd == "/today":
            await self._send_daily_totals(chat_id, user_id)
        elif cmd in ("/subscribe", "/pay"):
            await self._initiate_payment(chat_id, user_id)
        else:
            await telegram_service.send_message(
                chat_id, "Unknown command. Type /help for available commands."
            )

    # ── Image processing ───────────────────────────────────────────────────────

    async def _handle_image(self, message: dict, chat_id: int, user, photo, document):
        """Download image, check subscription, detect barcode vs food, analyse."""
        # Subscription gate
        can_scan = await self.user_repo.check_and_expire(user)
        if not can_scan:
            await telegram_service.send_subscription_required(chat_id, free_scans_left=0)
            return

        # Show typing indicator
        await telegram_service.send_chat_action(chat_id, "typing")

        # Download image bytes
        image_bytes, mime_type = await self._download_image(photo, document)
        if not image_bytes:
            await telegram_service.send_message(
                chat_id, "❌ Could not download your image. Please try again."
            )
            return

        # Detect barcode first (faster)
        if self._looks_like_barcode_image(message):
            await self._process_barcode(chat_id, user, image_bytes, message.get("message_id"))
        else:
            await self._process_food_image(chat_id, user, image_bytes, mime_type, message.get("message_id"))

    async def _process_food_image(self, chat_id: int, user, image_bytes: bytes, mime_type: str, reply_id: Optional[int]):
        nutrition = await nutrition_ai_service.analyse_food_image(image_bytes, mime_type)

        if nutrition.get("error") and not nutrition.get("calories"):
            await telegram_service.send_message(
                chat_id,
                f"⚠️ {nutrition['error']}\n\nTip: Try a clearer, well-lit photo.",
                reply_to_message_id=reply_id,
            )
            return

        # Deduct free scan if applicable
        if not user.is_subscription_active:
            await self.user_repo.increment_free_scan(user)
            scans_left = max(0, settings.FREE_TRIAL_SCANS - user.free_scans_used)
            if scans_left > 0:
                await telegram_service.send_message(
                    chat_id,
                    f"ℹ️ <i>{scans_left} free scan(s) remaining. Subscribe for unlimited access.</i>",
                )
            else:
                await telegram_service.send_subscription_required(chat_id, free_scans_left=0)

        await telegram_service.send_nutrition_result(chat_id, nutrition, reply_to=reply_id)
        await self.scan_repo.save_scan(user.id, nutrition, ScanType.IMAGE)

    async def _process_barcode(self, chat_id: int, user, image_bytes: bytes, reply_id: Optional[int]):
        await telegram_service.send_chat_action(chat_id, "typing")
        result = await barcode_service.process_barcode_image(image_bytes)

        if result.get("error"):
            # Barcode failed — try food image analysis as fallback
            await telegram_service.send_message(chat_id, result["error"])
            return

        # Deduct free scan
        if not user.is_subscription_active:
            await self.user_repo.increment_free_scan(user)

        await telegram_service.send_nutrition_result(chat_id, result, reply_to=reply_id)
        await self.scan_repo.save_scan(user.id, result, ScanType.BARCODE)

    async def _handle_text(self, text: str, chat_id: int, user):
        """Handle plain text — interpret as food query."""
        can_scan = await self.user_repo.check_and_expire(user)
        if not can_scan:
            await telegram_service.send_subscription_required(chat_id, free_scans_left=0)
            return

        await telegram_service.send_chat_action(chat_id, "typing")
        nutrition = await nutrition_ai_service.analyse_food_text(text)

        if nutrition.get("error") and not nutrition.get("calories"):
            await telegram_service.send_message(chat_id, f"⚠️ {nutrition['error']}")
            return

        if not user.is_subscription_active:
            await self.user_repo.increment_free_scan(user)

        await telegram_service.send_nutrition_result(chat_id, nutrition)
        await self.scan_repo.save_scan(user.id, nutrition, ScanType.TEXT)

    # ── Payment ────────────────────────────────────────────────────────────────

    async def _initiate_payment(self, chat_id: int, user_id: int):
        order_id = telebirr_service.generate_order_id(user_id)
        result = await telebirr_service.create_payment(user_id, order_id)

        if result.get("error"):
            await telegram_service.send_subscription_required(chat_id)
            return

        payment_url = result.get("payment_url")
        await self.payment_repo.create(
            user_id=user_id,
            order_id=order_id,
            amount=settings.SUBSCRIPTION_PRICE_ETB,
            payment_url=payment_url,
        )

        if payment_url and not result.get("mock"):
            keyboard = telegram_service.inline_keyboard([
                [telegram_service.url_button("💳 Pay with Telebirr", payment_url)],
                [telegram_service.button("✅ Verify Payment", f"verify_payment:{user_id}")],
            ])
            await telegram_service.send_message(
                chat_id,
                f"💰 <b>Complete your subscription</b>\n\n"
                f"Amount: <b>{settings.SUBSCRIPTION_PRICE_ETB:.0f} ETB</b>\n"
                f"Click the button below to pay securely via Telebirr.",
                reply_markup=keyboard,
            )
        else:
            await telegram_service.send_subscription_required(chat_id)

    async def _handle_payment_verification(self, chat_id: int, user_id: int):
        """Manual verification — check for completed payment in DB."""
        user = await self.user_repo.get(user_id)
        if user and user.is_subscription_active:
            await telegram_service.send_message(
                chat_id,
                "✅ Your subscription is already active!\n"
                f"Expires: {user.subscription_expiry.strftime('%d %b %Y') if user.subscription_expiry else 'N/A'}",
            )
            return

        # Check for a completed payment that wasn't applied
        payment = await self.payment_repo.get_pending_for_user(user_id)
        if payment:
            await telegram_service.send_message(
                chat_id,
                "⏳ Your payment is pending verification.\n"
                "It usually activates within 5 minutes.\n"
                "If it doesn't, please contact support with your Telebirr transaction reference.",
            )
        else:
            await telegram_service.send_message(
                chat_id,
                "⚠️ No pending payment found.\n\n"
                "If you paid manually:\n"
                f"• Telebirr number: <code>0942791319</code>\n"
                f"• Make sure you included your Telegram ID <code>{user_id}</code> in the note/reason\n\n"
                "Payment usually activates within 5 minutes after confirmation.",
            )

    # ── Info commands ──────────────────────────────────────────────────────────

    async def _send_help(self, chat_id: int):
        text = (
            "🤖 <b>NutriScan AI — Help</b>\n\n"
            "<b>📸 Scan Food</b>\n"
            "Send any food photo for instant nutrition analysis.\n\n"
            "<b>🔖 Scan Barcode</b>\n"
            "Send a barcode image to look up packaged food.\n\n"
            "<b>💬 Text Lookup</b>\n"
            "Type any food name for a quick estimate.\n\n"
            "<b>Commands:</b>\n"
            "/status — check subscription status\n"
            "/history — your last 10 scans\n"
            "/today — today's calorie & macro totals\n"
            "/subscribe — get a subscription\n"
            "/help — show this message"
        )
        await telegram_service.send_message(chat_id, text)

    async def _send_status(self, chat_id: int, user_id: int):
        user = await self.user_repo.get(user_id)
        if not user:
            return

        if user.is_subscription_active:
            expiry = user.subscription_expiry.strftime("%d %b %Y") if user.subscription_expiry else "N/A"
            status_text = f"✅ <b>Active</b> — expires {expiry}"
        elif user.has_free_scans:
            left = settings.FREE_TRIAL_SCANS - user.free_scans_used
            status_text = f"🆓 <b>Free Trial</b> — {left} scan(s) left"
        else:
            status_text = "🔒 <b>Inactive</b> — subscription required"

        await telegram_service.send_message(
            chat_id,
            f"📊 <b>Your Subscription</b>\n\n{status_text}\n\n"
            f"Total scans: {len(user.scans) if hasattr(user, 'scans') else '–'}",
        )

    async def _send_history(self, chat_id: int, user_id: int):
        scans = await self.scan_repo.get_user_history(user_id, limit=10)
        if not scans:
            await telegram_service.send_message(chat_id, "📭 No scans yet. Send a food photo to start!")
            return

        lines = ["📋 <b>Your Recent Scans</b>\n"]
        for s in scans:
            cal = f"{s.calories:.0f} kcal" if s.calories else "–"
            date_str = s.created_at.strftime("%d/%m %H:%M")
            lines.append(f"• {s.food_name or 'Unknown'} — {cal} <i>({date_str})</i>")

        await telegram_service.send_message(chat_id, "\n".join(lines))

    async def _send_daily_totals(self, chat_id: int, user_id: int):
        totals = await self.scan_repo.get_daily_totals(user_id)
        await telegram_service.send_message(
            chat_id,
            f"📅 <b>Today's Totals</b> ({totals['date']})\n\n"
            f"🔥 Calories: <b>{totals['calories']:.0f} kcal</b>\n"
            f"💪 Protein:  <b>{totals['protein_g']:.1f}g</b>\n"
            f"🍞 Carbs:    <b>{totals['carbs_g']:.1f}g</b>\n"
            f"🥑 Fat:      <b>{totals['fat_g']:.1f}g</b>",
        )

    # ── Helpers ────────────────────────────────────────────────────────────────

    async def _download_image(self, photo, document) -> tuple[Optional[bytes], str]:
        mime_type = "image/jpeg"
        if photo:
            # photos come as array — last item is highest resolution
            file_id = photo[-1]["file_id"]
        elif document:
            file_id = document["file_id"]
            mime_type = document.get("mime_type", "image/jpeg")
        else:
            return None, mime_type

        data = await telegram_service.download_photo(file_id)
        return data, mime_type

    def _looks_like_barcode_image(self, message: dict) -> bool:
        """Heuristic: caption contains 'barcode' keyword."""
        caption = message.get("caption", "").lower()
        return "barcode" in caption or "scan" in caption

    async def _answer_callback(self, query_id: str):
        await telegram_service.client.post(
            f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/answerCallbackQuery",
            json={"callback_query_id": query_id},
        )
