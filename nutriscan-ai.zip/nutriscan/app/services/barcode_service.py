"""
BarcodeService — decodes barcodes from images using pyzbar, then fetches
nutrition data from the Open Food Facts API (free, no key required).
Falls back to Claude Vision if barcode can't be decoded.
"""

import io
import logging
from typing import Optional

import httpx
from PIL import Image

logger = logging.getLogger(__name__)

OPEN_FOOD_FACTS_API = "https://world.openfoodfacts.org/api/v2/product"


class BarcodeService:
    def __init__(self):
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=10.0)
        return self._client

    def decode_barcode(self, image_bytes: bytes) -> Optional[str]:
        """
        Attempt to decode a barcode from raw image bytes.
        Requires pyzbar and Pillow.
        Returns the barcode string or None.
        """
        try:
            from pyzbar.pyzbar import decode as pyzbar_decode

            img = Image.open(io.BytesIO(image_bytes))
            # Try original, then grayscale
            for attempt in [img, img.convert("L")]:
                results = pyzbar_decode(attempt)
                if results:
                    value = results[0].data.decode("utf-8").strip()
                    logger.info(f"Barcode decoded: {value}")
                    return value
        except ImportError:
            logger.warning("pyzbar not installed — barcode decoding unavailable")
        except Exception as e:
            logger.warning(f"Barcode decode failed: {e}")
        return None

    async def fetch_nutrition(self, barcode: str) -> Optional[dict]:
        """
        Query Open Food Facts for a barcode.
        Returns a normalised nutrition dict or None if not found.
        """
        try:
            resp = await self.client.get(
                f"{OPEN_FOOD_FACTS_API}/{barcode}.json",
                headers={"User-Agent": "NutriScanAI/1.0 (contact@nutriscan.ai)"},
            )
            if resp.status_code != 200:
                return None

            data = resp.json()
            if data.get("status") != 1:
                return None

            product = data.get("product", {})
            nutriments = product.get("nutriments", {})

            name = (
                product.get("product_name_en")
                or product.get("product_name")
                or "Unknown Product"
            )
            brand = product.get("brands", "")
            full_name = f"{brand} {name}".strip() if brand else name

            serving = product.get("serving_size") or "100g"

            # Prefer per-serving values, fall back to per-100g
            def _val(key: str) -> Optional[float]:
                v = nutriments.get(f"{key}_serving") or nutriments.get(f"{key}_100g")
                try:
                    return round(float(v), 1) if v is not None else None
                except (ValueError, TypeError):
                    return None

            result = {
                "food_name": full_name,
                "serving_size": serving,
                "calories": _val("energy-kcal") or _val("energy"),
                "protein_g": _val("proteins"),
                "carbs_g": _val("carbohydrates"),
                "fat_g": _val("fat"),
                "fiber_g": _val("fiber"),
                "sugar_g": _val("sugars"),
                "sodium_mg": _val("sodium") and round((_val("sodium") or 0) * 1000, 0),
                "confidence": "high",
                "notes": f"Data sourced from Open Food Facts. Barcode: {barcode}",
                "error": None,
            }
            return result

        except Exception as e:
            logger.error(f"Open Food Facts API error for {barcode}: {e}")
            return None

    async def process_barcode_image(self, image_bytes: bytes) -> dict:
        """
        Full pipeline: decode barcode → fetch nutrition.
        Returns nutrition dict or error dict.
        """
        barcode = self.decode_barcode(image_bytes)

        if not barcode:
            return {
                "error": (
                    "⚠️ Could not detect a barcode in your image.\n\n"
                    "Tips:\n"
                    "• Make sure the barcode is in focus\n"
                    "• Hold the camera steady\n"
                    "• Ensure good lighting\n\n"
                    "Or send a regular photo of the food and I'll analyse it directly!"
                ),
                "barcode": None,
            }

        nutrition = await self.fetch_nutrition(barcode)

        if not nutrition:
            return {
                "error": (
                    f"📭 Barcode <code>{barcode}</code> not found in our database.\n\n"
                    "Send a photo of the food label or the food itself and I'll estimate the nutrition!"
                ),
                "barcode": barcode,
            }

        nutrition["barcode"] = barcode
        return nutrition


barcode_service = BarcodeService()
