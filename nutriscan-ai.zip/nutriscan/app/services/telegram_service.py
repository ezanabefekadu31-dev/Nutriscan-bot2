"""
Telegram API wrapper — manages webhook registration, message sending,
photo downloads, and inline keyboard helpers.
"""

import logging
from typing import Any, Optional
import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

TELEGRAM_API = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}"
TELEGRAM_FILE_API = f"https://api.telegram.org/file/bot{settings.TELEGRAM_BOT_TOKEN}"


class TelegramService:
    def __init__(self):
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def set_webhook(self, url: str) -> bool:
        """Register webhook with Telegram."""
        payload: dict[str, Any] = {
            "url": f"{url}/webhook/telegram",
            "allowed_updates": ["message", "callback_query"],
            "drop_pending_updates": True,
        }
        if settings.TELEGRAM_WEBHOOK_SECRET:
            payload["secret_token"] = settings.TELEGRAM_WEBHOOK_SECRET

        resp = await self.client.post(f"{TELEGRAM_API}/setWebhook", json=payload)
        data = resp.json()
        if not data.get("ok"):
            logger.error(f"Webhook registration failed: {data}")
        return data.get("ok", False)

    async def send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: str = "HTML",
        reply_markup: Optional[dict] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> dict:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": parse_mode,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if reply_to_message_id:
            payload["reply_to_message_id"] = reply_to_message_id

        resp = await self.client.post(f"{TELEGRAM_API}/sendMessage", json=payload)
        return resp.json()

    async def send_chat_action(self, chat_id: int, action: str = "typing") -> None:
        await self.client.post(
            f"{TELEGRAM_API}/sendChatAction",
            json={"chat_id": chat_id, "action": action},
        )

    async def get_file(self, file_id: str) -> Optional[str]:
        """Get download path for a Telegram file."""
        resp = await self.client.get(f"{TELEGRAM_API}/getFile", params={"file_id": file_id})
        data = resp.json()
        if data.get("ok"):
            return data["result"]["file_path"]
        logger.error(f"getFile failed: {data}")
        return None

    async def download_file(self, file_path: str) -> Optional[bytes]:
        """Download file bytes from Telegram CDN."""
        url = f"{TELEGRAM_FILE_API}/{file_path}"
        resp = await self.client.get(url)
        if resp.status_code == 200:
            return resp.content
        logger.error(f"Download failed: {resp.status_code}")
        return None

    async def download_photo(self, file_id: str) -> Optional[bytes]:
        """Convenience: get file path then download bytes."""
        file_path = await self.get_file(file_id)
        if not file_path:
            return None
        return await self.download_file(file_path)

    # ── Keyboard helpers ───────────────────────────────────────────────────────

    @staticmethod
    def inline_keyboard(buttons: list[list[dict]]) -> dict:
        return {"inline_keyboard": buttons}

    @staticmethod
    def button(text: str, callback_data: str) -> dict:
        return {"text": text, "callback_data": callback_data}

    @staticmethod
    def url_button(text: str, url: str) -> dict:
        return {"text": text, "url": url}

    # ── Pre-built message templates ────────────────────────────────────────────

    async def send_subscription_required(self, chat_id: int, free_scans_left: int = 0):
        """Show paywall message with payment instructions."""
        from app.core.config import settings

        price = settings.SUBSCRIPTION_PRICE_ETB

        if free_scans_left > 0:
            intro = f"⚠️ You have <b>{free_scans_left} free scan(s)</b> remaining after this."
        else:
            intro = "🔒 <b>Subscription required</b> to continue using NutriScan AI."

        text = (
            f"{intro}\n\n"
            f"📦 <b>NutriScan AI Premium</b>\n"
            f"• Unlimited food & barcode scans\n"
            f"• Detailed macro breakdown\n"
            f"• Meal history & daily tracking\n\n"
            f"💰 <b>{price:.0f} ETB / month</b>\n\n"
            f"📲 <b>How to subscribe via Telebirr:</b>\n"
            f"1. Open your Telebirr app\n"
            f"2. Tap <i>Send Money</i>\n"
            f"3. Enter number: <code>0942791319</code>\n"
            f"4. Amount: <b>{price:.0f} ETB</b>\n"
            f"5. In the reason/note field enter your Telegram ID: <code>{chat_id}</code>\n"
            f"6. Confirm payment — your account activates within minutes.\n\n"
            f"✉️ Already paid? Tap the button below."
        )

        keyboard = self.inline_keyboard([
            [self.button("✅ I've Paid — Verify Now", f"verify_payment:{chat_id}")],
            [self.button("ℹ️ Help", "help")],
        ])
        await self.send_message(chat_id, text, reply_markup=keyboard)

    async def send_nutrition_result(self, chat_id: int, result: dict, reply_to: Optional[int] = None):
        """Format and send a nutrition analysis card."""
        name = result.get("food_name", "Unknown Food")
        cal = result.get("calories", "–")
        protein = result.get("protein_g", "–")
        carbs = result.get("carbs_g", "–")
        fat = result.get("fat_g", "–")
        fiber = result.get("fiber_g")
        sugar = result.get("sugar_g")
        sodium = result.get("sodium_mg")
        serving = result.get("serving_size", "1 serving")
        confidence = result.get("confidence", "medium")
        notes = result.get("notes", "")

        conf_emoji = {"high": "🟢", "medium": "🟡", "low": "🔴"}.get(confidence, "🟡")

        extras = ""
        if fiber is not None:
            extras += f"\n  🌾 Fiber: <b>{fiber:.1f}g</b>"
        if sugar is not None:
            extras += f"\n  🍬 Sugar: <b>{sugar:.1f}g</b>"
        if sodium is not None:
            extras += f"\n  🧂 Sodium: <b>{sodium:.0f}mg</b>"

        text = (
            f"🥗 <b>{name}</b>\n"
            f"<i>Per {serving}</i>\n"
            f"━━━━━━━━━━━━━━━\n"
            f"🔥 Calories: <b>{cal} kcal</b>\n"
            f"💪 Protein:  <b>{protein}g</b>\n"
            f"🍞 Carbs:    <b>{carbs}g</b>\n"
            f"🥑 Fat:      <b>{fat}g</b>"
            f"{extras}\n"
            f"━━━━━━━━━━━━━━━\n"
            f"{conf_emoji} Confidence: <i>{confidence.title()}</i>"
        )
        if notes:
            text += f"\n\n💡 <i>{notes}</i>"

        await self.send_message(chat_id, text, reply_to_message_id=reply_to)

    async def send_welcome(self, chat_id: int, name: str, free_scans: int):
        text = (
            f"👋 Welcome to <b>NutriScan AI</b>, {name}!\n\n"
            f"📸 Send me a photo of any food and I'll instantly analyse:\n"
            f"  • Calories  • Protein  • Carbs  • Fat\n\n"
            f"🔖 I can also scan <b>barcodes</b> on packaged food.\n\n"
            f"🎁 You have <b>{free_scans} free scans</b> to try before subscribing.\n\n"
            f"Just send a photo to get started!"
        )
        await self.send_message(chat_id, text)


telegram_service = TelegramService()
