"""
TelebirrService — handles payment initiation and verification for the
Ethiopian Telebirr mobile money platform.

Note: Telebirr's production API requires a signed contract and RSA encryption.
This implementation follows their documented flow. For MVP/testing, a simplified
verification flow is included that can be toggled with TELEBIRR_MOCK_MODE=true.
"""

import base64
import hashlib
import json
import logging
import time
import uuid
from datetime import datetime
from typing import Optional

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)


class TelebirrService:
    """
    Telebirr H5 Web Payment integration.
    Docs: https://developer.ethiotelecom.et/docs/TelebirrPayment
    """

    def __init__(self):
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=15.0, verify=False)  # Telebirr uses self-signed cert
        return self._client

    def generate_order_id(self, user_id: int) -> str:
        """Generate unique order ID embedding Telegram user_id."""
        return f"NS_{user_id}_{int(time.time())}_{uuid.uuid4().hex[:6].upper()}"

    def _build_sign_string(self, params: dict) -> str:
        """Build the signature string per Telebirr spec (sorted keys, & joined)."""
        sorted_params = sorted(params.items())
        return "&".join(f"{k}={v}" for k, v in sorted_params if v is not None)

    def _sha256_sign(self, data: str) -> str:
        """SHA-256 hash of the data string."""
        return hashlib.sha256(data.encode("utf-8")).hexdigest().upper()

    def _rsa_encrypt(self, plaintext: str) -> str:
        """
        RSA-encrypt with Telebirr's public key.
        Requires: pip install cryptography
        """
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding

            public_key_pem = settings.TELEBIRR_PUBLIC_KEY
            if not public_key_pem.startswith("-----"):
                # Raw base64 key — wrap it
                public_key_pem = (
                    f"-----BEGIN PUBLIC KEY-----\n{public_key_pem}\n-----END PUBLIC KEY-----"
                )

            public_key = serialization.load_pem_public_key(public_key_pem.encode())
            encrypted = public_key.encrypt(plaintext.encode("utf-8"), padding.PKCS1v15())
            return base64.b64encode(encrypted).decode("utf-8")
        except Exception as e:
            logger.error(f"RSA encryption failed: {e}")
            raise

    async def create_payment(self, user_id: int, order_id: str) -> dict:
        """
        Initiate a Telebirr H5 payment and return the payment URL.
        Returns {"payment_url": str, "order_id": str} or {"error": str}
        """
        if not settings.TELEBIRR_APP_ID:
            # Mock mode for development/demo
            logger.warning("Telebirr not configured — returning mock payment URL")
            return {
                "payment_url": f"https://mock-telebirr.example.com/pay?order={order_id}&amount={settings.SUBSCRIPTION_PRICE_ETB}",
                "order_id": order_id,
                "mock": True,
            }

        try:
            timestamp = str(int(time.time() * 1000))
            nonce = uuid.uuid4().hex

            # Inner payload (to be encrypted)
            inner_payload = {
                "appId": settings.TELEBIRR_APP_ID,
                "appKey": settings.TELEBIRR_APP_KEY,
                "notifyUrl": settings.PAYMENT_NOTIFY_URL,
                "outTradeNo": order_id,
                "subject": "NutriScan AI - Monthly Subscription",
                "timeoutExpress": "30",                     # minutes
                "timestamp": timestamp,
                "totalAmount": f"{settings.SUBSCRIPTION_PRICE_ETB:.2f}",
                "shortCode": "0942791319",                  # recipient Telebirr number
                "receiveName": "NutriScan AI",
                "receiverMsisdn": "0942791319",             # explicit recipient phone
                "returnUrl": settings.PAYMENT_RETURN_URL,
                "nonce": nonce,
            }

            # Sort and sign
            sign_str = self._build_sign_string(inner_payload)
            inner_payload["sign"] = self._sha256_sign(sign_str)

            # Encrypt inner payload with Telebirr's public key
            encrypted_payload = self._rsa_encrypt(json.dumps(inner_payload))

            outer_payload = {
                "appid": settings.TELEBIRR_APP_ID,
                "sign": inner_payload["sign"],
                "ussd": encrypted_payload,
            }

            resp = await self.client.post(
                f"{settings.TELEBIRR_BASE_URL}/toTradeWebpay",
                json=outer_payload,
            )
            result = resp.json()

            if result.get("code") == "0":
                return {
                    "payment_url": result["data"]["toPayUrl"],
                    "order_id": order_id,
                }
            else:
                logger.error(f"Telebirr payment creation failed: {result}")
                return {"error": result.get("msg", "Payment initiation failed")}

        except Exception as e:
            logger.exception(f"Telebirr create_payment error: {e}")
            return {"error": str(e)}

    def verify_webhook_signature(self, payload: dict) -> bool:
        """
        Verify an incoming Telebirr webhook notification signature.
        """
        if not settings.TELEBIRR_APP_KEY:
            return True  # Skip verification in dev/mock mode

        received_sign = payload.pop("sign", None)
        computed = self._sha256_sign(self._build_sign_string(payload))
        payload["sign"] = received_sign  # restore

        if computed != received_sign:
            logger.warning(f"Telebirr webhook signature mismatch. Computed={computed}, Received={received_sign}")
            return False
        return True

    def extract_user_id_from_order(self, order_id: str) -> Optional[int]:
        """Extract Telegram user_id from order_id format: NS_{user_id}_{timestamp}_{nonce}"""
        try:
            parts = order_id.split("_")
            if len(parts) >= 2 and parts[0] == "NS":
                return int(parts[1])
        except (ValueError, IndexError):
            pass
        logger.warning(f"Could not extract user_id from order_id: {order_id}")
        return None


telebirr_service = TelebirrService()
