"""
NutritionAIService — uses Claude Vision to analyse food images and extract
structured macro-nutrient data with confidence scoring.
"""

import base64
import json
import logging
import re
from typing import Optional

import anthropic

from app.core.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are NutriScan AI, an expert nutritionist and food scientist.
Analyse food images and return ONLY a JSON object — no markdown, no explanation.

JSON schema:
{
  "food_name": "string (descriptive name of the dish/food)",
  "serving_size": "string (e.g. '1 plate ~350g', '1 cup ~240ml')",
  "calories": number,
  "protein_g": number,
  "carbs_g": number,
  "fat_g": number,
  "fiber_g": number or null,
  "sugar_g": number or null,
  "sodium_mg": number or null,
  "confidence": "high" | "medium" | "low",
  "notes": "string — brief relevant notes (e.g. allergens, notable ingredients, or why confidence is low)",
  "error": null or "string — only set if image is not food-related"
}

Rules:
- All numeric values must be reasonable estimates based on typical serving sizes.
- If image quality is poor but food is identifiable, set confidence to "low" and still estimate.
- If the image clearly does not contain food, set error and null out nutrition fields.
- confidence "high"   = clearly identifiable, standard preparation
- confidence "medium" = identifiable but sauce/ingredients uncertain
- confidence "low"    = poor quality or unusual preparation, best guess
"""


class NutritionAIService:
    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def analyse_food_image(self, image_bytes: bytes, mime_type: str = "image/jpeg") -> dict:
        """
        Send image bytes to Claude Vision and return parsed nutrition dict.
        Falls back gracefully on parse errors.
        """
        b64 = base64.standard_b64encode(image_bytes).decode("utf-8")

        try:
            message = await self.client.messages.create(
                model="claude-opus-4-5",
                max_tokens=512,
                system=SYSTEM_PROMPT,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": mime_type,
                                    "data": b64,
                                },
                            },
                            {
                                "type": "text",
                                "text": "Analyse this food image and return the JSON nutritional breakdown.",
                            },
                        ],
                    }
                ],
            )

            raw_text = message.content[0].text
            return self._parse_response(raw_text)

        except anthropic.APIError as e:
            logger.error(f"Anthropic API error: {e}")
            return self._error_result("AI service temporarily unavailable. Please try again.")
        except Exception as e:
            logger.exception(f"Unexpected error in analyse_food_image: {e}")
            return self._error_result("Failed to analyse image.")

    async def analyse_food_text(self, food_description: str) -> dict:
        """Analyse nutrition from a text description (fallback for unclear images)."""
        try:
            message = await self.client.messages.create(
                model="claude-opus-4-5",
                max_tokens=512,
                system=SYSTEM_PROMPT,
                messages=[
                    {
                        "role": "user",
                        "content": f"Provide nutritional breakdown for: {food_description}",
                    }
                ],
            )
            return self._parse_response(message.content[0].text)
        except Exception as e:
            logger.exception(f"Error in analyse_food_text: {e}")
            return self._error_result("Failed to analyse food description.")

    def _parse_response(self, raw: str) -> dict:
        """Parse Claude's JSON response with fallback extraction."""
        # Strip any accidental markdown fences
        clean = re.sub(r"```(?:json)?", "", raw).strip().strip("`")

        try:
            data = json.loads(clean)
            # Validate required fields exist
            if "calories" in data or "error" in data:
                return data
        except json.JSONDecodeError:
            pass

        # Attempt to extract JSON block from messy response
        match = re.search(r"\{.*\}", clean, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass

        logger.warning(f"Could not parse AI response: {raw[:200]}")
        return self._error_result("Could not parse nutrition data. Please try a clearer image.")

    @staticmethod
    def _error_result(message: str) -> dict:
        return {
            "error": message,
            "food_name": None,
            "calories": None,
            "protein_g": None,
            "carbs_g": None,
            "fat_g": None,
            "fiber_g": None,
            "sugar_g": None,
            "sodium_mg": None,
            "confidence": "low",
            "serving_size": None,
            "notes": None,
        }


nutrition_ai_service = NutritionAIService()
