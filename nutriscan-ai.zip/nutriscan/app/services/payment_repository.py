"""
PaymentRepository — manages payment records in the database.
"""

import logging
from datetime import datetime
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.scan_history import Payment, PaymentStatus

logger = logging.getLogger(__name__)


class PaymentRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, user_id: int, order_id: str, amount: float, payment_url: Optional[str] = None) -> Payment:
        payment = Payment(
            user_id=user_id,
            order_id=order_id,
            amount_etb=amount,
            status=PaymentStatus.PENDING,
            payment_url=payment_url,
        )
        self.db.add(payment)
        await self.db.flush()
        return payment

    async def get_by_order_id(self, order_id: str) -> Optional[Payment]:
        result = await self.db.execute(select(Payment).where(Payment.order_id == order_id))
        return result.scalar_one_or_none()

    async def mark_completed(self, order_id: str, transaction_id: str, payload: str) -> Optional[Payment]:
        payment = await self.get_by_order_id(order_id)
        if payment:
            payment.status = PaymentStatus.COMPLETED
            payment.telebirr_transaction_id = transaction_id
            payment.webhook_payload = payload
            payment.completed_at = datetime.utcnow()
            await self.db.flush()
        return payment

    async def mark_failed(self, order_id: str) -> Optional[Payment]:
        payment = await self.get_by_order_id(order_id)
        if payment:
            payment.status = PaymentStatus.FAILED
            await self.db.flush()
        return payment

    async def get_pending_for_user(self, user_id: int) -> Optional[Payment]:
        result = await self.db.execute(
            select(Payment)
            .where(Payment.user_id == user_id, Payment.status == PaymentStatus.PENDING)
            .order_by(Payment.created_at.desc())
        )
        return result.scalar_one_or_none()
