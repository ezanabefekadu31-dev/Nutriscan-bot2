"""
User model — stores Telegram user info, subscription state, and free-trial counter.
"""

from datetime import datetime
from enum import Enum as PyEnum
from typing import Optional

from sqlalchemy import BigInteger, DateTime, Enum, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class SubscriptionStatus(str, PyEnum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    TRIAL = "trial"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # Telegram user_id
    username: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)

    # Subscription
    subscription_status: Mapped[SubscriptionStatus] = mapped_column(
        Enum(SubscriptionStatus), default=SubscriptionStatus.TRIAL
    )
    subscription_expiry: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Free trial
    free_scans_used: Mapped[int] = mapped_column(Integer, default=0)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=func.now(), onupdate=func.now())
    last_active: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    scans: Mapped[list["ScanHistory"]] = relationship(back_populates="user", lazy="select")
    payments: Mapped[list["Payment"]] = relationship(back_populates="user", lazy="select")

    @property
    def is_subscription_active(self) -> bool:
        """True when the user has a valid, non-expired subscription."""
        if self.subscription_status == SubscriptionStatus.ACTIVE:
            if self.subscription_expiry and self.subscription_expiry > datetime.utcnow():
                return True
            # Expired — caller should update status
        return False

    @property
    def has_free_scans(self) -> bool:
        from app.core.config import settings
        return self.free_scans_used < settings.FREE_TRIAL_SCANS

    @property
    def can_scan(self) -> bool:
        return self.is_subscription_active or self.has_free_scans

    @property
    def display_name(self) -> str:
        parts = [self.first_name, self.last_name]
        name = " ".join(p for p in parts if p)
        return name or self.username or str(self.id)
