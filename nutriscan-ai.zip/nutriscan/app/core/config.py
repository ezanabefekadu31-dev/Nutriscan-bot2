"""
Application configuration — all secrets loaded from environment variables.
Never hardcode API keys or tokens.
"""

from functools import lru_cache
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Core ──────────────────────────────────────────────────────────────────
    APP_NAME: str = "NutriScan AI"
    DEBUG: bool = False
    SECRET_KEY: str = "change-me-in-production"

    # ── Telegram ──────────────────────────────────────────────────────────────
    TELEGRAM_BOT_TOKEN: str
    TELEGRAM_WEBHOOK_SECRET: str = ""   # optional but recommended
    WEBHOOK_URL: str = ""               # e.g. https://your-app.onrender.com/webhook/telegram

    # ── Anthropic (Claude Vision) ─────────────────────────────────────────────
    ANTHROPIC_API_KEY: str

    # ── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: str = "sqlite+aiosqlite:///./nutriscan.db"

    # ── Telebirr Payment ──────────────────────────────────────────────────────
    TELEBIRR_APP_ID: str = ""
    TELEBIRR_APP_KEY: str = ""
    TELEBIRR_PUBLIC_KEY: str = ""       # Telebirr RSA public key for encryption
    TELEBIRR_MERCHANT_CODE: str = "0942791319"
    TELEBIRR_SHORT_CODE: str = "0942791319"
    TELEBIRR_BASE_URL: str = "https://196.188.120.3:38443/amole/payment"
    PAYMENT_NOTIFY_URL: str = ""        # Your /payment/telebirr-webhook URL
    PAYMENT_RETURN_URL: str = ""        # Redirect after payment

    # ── Subscription Pricing ──────────────────────────────────────────────────
    SUBSCRIPTION_PRICE_ETB: float = 199.0
    SUBSCRIPTION_DAYS: int = 30
    FREE_TRIAL_SCANS: int = 3

    # ── Admin ─────────────────────────────────────────────────────────────────
    ADMIN_SECRET: str = "change-admin-secret"

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
