#!/usr/bin/env python3
"""
NutriScan AI — Local development utilities.

Usage:
    python dev.py serve          # Start FastAPI dev server with hot-reload
    python dev.py set-webhook    # Register webhook via ngrok tunnel
    python dev.py activate <id>  # Manually activate a user's subscription
    python dev.py stats          # Show user stats
    python dev.py verify <order> # Manually verify a payment
"""

import asyncio
import sys
import os

# Ensure local .env is loaded
from dotenv import load_dotenv
load_dotenv()


def serve():
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )


async def set_webhook_via_ngrok():
    """Auto-detect ngrok tunnel and register Telegram webhook."""
    import httpx
    try:
        resp = httpx.get("http://localhost:4040/api/tunnels", timeout=3)
        tunnels = resp.json().get("tunnels", [])
        https_tunnel = next((t for t in tunnels if t["proto"] == "https"), None)
        if not https_tunnel:
            print("❌ No HTTPS ngrok tunnel found. Run: ngrok http 8000")
            return
        url = https_tunnel["public_url"]
        print(f"🌐 Found ngrok tunnel: {url}")
    except Exception:
        url = input("Enter your public URL (e.g. https://abc.ngrok.io): ").strip()

    from app.services.telegram_service import telegram_service
    success = await telegram_service.set_webhook(url)
    if success:
        print(f"✅ Webhook registered: {url}/webhook/telegram")
    else:
        print("❌ Webhook registration failed")
    await telegram_service.close()


async def activate_user(user_id: int):
    from app.core.database import init_db, AsyncSessionLocal
    from app.services.user_service import UserRepository

    await init_db()
    async with AsyncSessionLocal() as db:
        repo = UserRepository(db)
        user = await repo.activate_subscription(user_id)
        if user:
            print(f"✅ Activated subscription for user {user_id}")
            print(f"   Expires: {user.subscription_expiry}")
        else:
            print(f"❌ User {user_id} not found")
        await db.commit()


async def show_stats():
    from app.core.database import init_db, AsyncSessionLocal
    from app.services.user_service import UserRepository

    await init_db()
    async with AsyncSessionLocal() as db:
        repo = UserRepository(db)
        stats = await repo.get_stats()
        print("\n📊 NutriScan AI Stats")
        print("─" * 30)
        for k, v in stats.items():
            print(f"  {k}: {v}")


async def verify_payment(order_id: str):
    from app.core.database import init_db, AsyncSessionLocal
    from app.routers.payment import _activate_payment

    await init_db()
    async with AsyncSessionLocal() as db:
        result = await _activate_payment(db, order_id, "DEV_MANUAL", '{"dev": true}')
        await db.commit()
        print(f"Result: {result}")


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] == "serve":
        serve()
    elif args[0] == "set-webhook":
        asyncio.run(set_webhook_via_ngrok())
    elif args[0] == "activate" and len(args) > 1:
        asyncio.run(activate_user(int(args[1])))
    elif args[0] == "stats":
        asyncio.run(show_stats())
    elif args[0] == "verify" and len(args) > 1:
        asyncio.run(verify_payment(args[1]))
    else:
        print(__doc__)
