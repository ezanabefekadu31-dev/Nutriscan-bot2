# 🥗 NutriScan AI — Telegram Bot

AI-powered nutrition analysis bot for Telegram. Send a food photo or barcode image and get instant macro breakdowns — powered by Claude Vision. Includes a full subscription system with Telebirr payment integration.

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 📸 Food photo analysis | Claude Vision identifies dish + estimates calories, protein, carbs, fat |
| 🔖 Barcode scanning | pyzbar decodes EAN/UPC barcodes; Open Food Facts provides nutrition data |
| 💬 Text lookup | Type any food name for an instant estimate |
| 🔒 Subscription paywall | 3 free trial scans, then 199 ETB/month via Telebirr |
| 📊 Meal history | `/history` shows last 10 scans |
| 📅 Daily totals | `/today` shows today's cumulative macros |
| 🔔 Auto-activation | Telebirr webhook activates subscription within seconds of payment |

---

## 🗂 Project Structure

```
nutriscan/
├── app/
│   ├── main.py                   # FastAPI app + lifespan
│   ├── core/
│   │   ├── config.py             # Pydantic settings (env vars)
│   │   └── database.py           # Async SQLAlchemy engine
│   ├── models/
│   │   ├── user.py               # User + subscription model
│   │   └── scan_history.py       # ScanHistory + Payment models
│   ├── routers/
│   │   ├── telegram.py           # POST /webhook/telegram
│   │   ├── payment.py            # POST /payment/telebirr-webhook
│   │   ├── health.py             # GET  /health
│   │   └── admin.py              # POST /admin/* (protected)
│   └── services/
│       ├── telegram_service.py   # Telegram API wrapper
│       ├── message_handler.py    # Core bot logic dispatcher
│       ├── nutrition_ai_service.py # Claude Vision integration
│       ├── barcode_service.py    # pyzbar + Open Food Facts
│       ├── payment_service.py    # Telebirr payment initiation
│       ├── user_service.py       # User DB operations
│       ├── scan_service.py       # Scan history DB operations
│       └── payment_repository.py # Payment DB operations
├── dev.py                        # Local dev helper CLI
├── requirements.txt
├── Dockerfile
├── render.yaml                   # One-click Render deploy
├── railway.toml                  # Railway deploy config
└── .env.example                  # Environment variable template
```

---

## 🚀 Quick Start (Local Development)

### 1. Prerequisites

```bash
# Python 3.12+
python --version

# libzbar for barcode scanning
# Ubuntu/Debian:
sudo apt-get install libzbar0
# macOS:
brew install zbar
```

### 2. Clone & install

```bash
git clone https://github.com/your-username/nutriscan-ai.git
cd nutriscan-ai

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

### 3. Configure environment

```bash
cp .env.example .env
```

Open `.env` and fill in:
- `TELEGRAM_BOT_TOKEN` — from [@BotFather](https://t.me/BotFather)
- `ANTHROPIC_API_KEY` — from [console.anthropic.com](https://console.anthropic.com)
- Leave Telebirr fields blank for now (mock mode will activate)

### 4. Start the server

```bash
python dev.py serve
# Server running at http://localhost:8000
```

### 5. Expose locally with ngrok (required for Telegram webhook)

```bash
# In a new terminal:
ngrok http 8000

# Then register the webhook:
python dev.py set-webhook
# ✅ Webhook registered: https://abc123.ngrok.io/webhook/telegram
```

### 6. Test the bot

Open your bot in Telegram and send `/start`. Then send a food photo!

---

## 🌐 Production Deployment

### Option A: Render (Recommended — easiest)

1. **Push to GitHub:**
   ```bash
   git init && git add . && git commit -m "Initial commit"
   git remote add origin https://github.com/your-username/nutriscan-ai.git
   git push -u origin main
   ```

2. **Deploy on Render:**
   - Go to [dashboard.render.com](https://dashboard.render.com)
   - Click **New → Blueprint**
   - Connect your GitHub repo — Render auto-reads `render.yaml`
   - Fill in the secret environment variables in the dashboard:
     - `TELEGRAM_BOT_TOKEN`
     - `TELEGRAM_WEBHOOK_SECRET`
     - `ANTHROPIC_API_KEY`
     - `ADMIN_SECRET`
     - Telebirr credentials (when ready)

3. **After first deploy**, copy your Render URL (e.g. `https://nutriscan-ai.onrender.com`) and update:
   - `WEBHOOK_URL=https://nutriscan-ai.onrender.com`
   - `PAYMENT_NOTIFY_URL=https://nutriscan-ai.onrender.com/payment/telebirr-webhook`
   - `PAYMENT_RETURN_URL=https://nutriscan-ai.onrender.com/payment/success`

4. **Re-deploy** (or use the admin endpoint to re-register the webhook):
   ```bash
   curl -X POST https://nutriscan-ai.onrender.com/admin/set-webhook \
     -H "x-admin-secret: YOUR_ADMIN_SECRET" \
     -G --data-urlencode "url=https://nutriscan-ai.onrender.com"
   ```

---

### Option B: Railway

1. Install Railway CLI:
   ```bash
   npm install -g @railway/cli
   railway login
   ```

2. Deploy:
   ```bash
   railway init
   railway up
   ```

3. Add environment variables in the Railway dashboard under **Variables**.

4. Add a PostgreSQL plugin in Railway for production database.

5. Register webhook after deploy:
   ```bash
   RAILWAY_URL=$(railway domain)
   curl -X POST https://$RAILWAY_URL/admin/set-webhook \
     -H "x-admin-secret: YOUR_ADMIN_SECRET" \
     -G --data-urlencode "url=https://$RAILWAY_URL"
   ```

---

### Option C: Docker (VPS/self-hosted)

```bash
# Build image
docker build -t nutriscan-ai .

# Run with env file
docker run -d \
  --name nutriscan-ai \
  --env-file .env \
  -p 8000:8000 \
  --restart unless-stopped \
  nutriscan-ai

# Check logs
docker logs -f nutriscan-ai
```

Use **nginx** as a reverse proxy with an SSL cert (Let's Encrypt) in front of port 8000.

---

## 💳 Telebirr Payment Integration

### Developer Registration

1. Visit [developer.ethiotelecom.et](https://developer.ethiotelecom.et)
2. Register as a merchant and request API access
3. Obtain: `App ID`, `App Key`, `Short Code`, `RSA Public Key`

### Payment Flow

```
User sends /subscribe
    │
    ▼
Bot creates order_id: NS_{user_id}_{timestamp}_{nonce}
    │
    ▼
POST /amole/payment/toTradeWebpay  ──► Telebirr API
    │
    ▼
Bot sends payment URL to user  ──► User pays in Telebirr app
    │
    ▼
Telebirr POSTs to /payment/telebirr-webhook
    │
    ▼
Webhook verifies signature + extracts user_id from order_id
    │
    ▼
DB: subscription_status=active, expiry=now+30days
    │
    ▼
Bot sends "🎉 Payment confirmed!" to user
```

### Testing Without Telebirr Credentials

Leave Telebirr fields blank in `.env` — the bot enters **mock mode** and shows manual payment instructions. You can manually activate users:

```bash
# Activate user locally:
python dev.py activate 123456789

# Activate user via API:
curl -X POST https://your-app.com/admin/activate \
  -H "x-admin-secret: YOUR_ADMIN_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"user_id": 123456789}'
```

### Manual Payment Verification (fallback)

When a user pays manually but the webhook didn't fire:

```bash
curl -X POST https://your-app.com/payment/manual-verify \
  -H "Content-Type: application/json" \
  -d '{
    "admin_secret": "YOUR_ADMIN_SECRET",
    "order_id": "NS_123456789_1734567890_ABCDEF",
    "transaction_id": "TELEBIRR_TXN_REF"
  }'
```

---

## 🔌 API Reference

### Telegram Webhook
```
POST /webhook/telegram
Header: X-Telegram-Bot-Api-Secret-Token: <secret>
Body: Telegram Update JSON
```

### Telebirr Payment Webhook
```
POST /payment/telebirr-webhook
Body: Telebirr signed payment notification JSON
```

### Admin Endpoints
All require `X-Admin-Secret: <ADMIN_SECRET>` header.

```
GET  /admin/stats           — user & subscription stats
POST /admin/activate        — activate user subscription
POST /admin/set-webhook     — re-register Telegram webhook
POST /payment/manual-verify — manually verify a payment
```

### Health
```
GET /health    — liveness check
GET /health/db — database connectivity check
```

---

## 🤖 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome message + free scan count |
| `/help` | Usage instructions |
| `/status` | Subscription status & expiry date |
| `/history` | Last 10 food scans |
| `/today` | Today's cumulative macros |
| `/subscribe` | Get subscription payment link |

---

## 🗄 Database Schema

### `users`
| Column | Type | Description |
|--------|------|-------------|
| `id` | BIGINT PK | Telegram user_id |
| `username` | VARCHAR | Telegram username |
| `subscription_status` | ENUM | `trial` / `active` / `inactive` |
| `subscription_expiry` | DATETIME | Expiry timestamp |
| `free_scans_used` | INT | Free trial scans consumed |

### `scan_history`
| Column | Type | Description |
|--------|------|-------------|
| `id` | INT PK | Auto-increment |
| `user_id` | BIGINT FK | → users.id |
| `scan_type` | ENUM | `image` / `barcode` / `text` |
| `food_name` | VARCHAR | Identified food name |
| `calories` | FLOAT | kcal |
| `protein_g` | FLOAT | grams |
| `carbs_g` | FLOAT | grams |
| `fat_g` | FLOAT | grams |

### `payments`
| Column | Type | Description |
|--------|------|-------------|
| `id` | INT PK | Auto-increment |
| `user_id` | BIGINT FK | → users.id |
| `order_id` | VARCHAR | `NS_{user_id}_{ts}_{nonce}` |
| `telebirr_transaction_id` | VARCHAR | Telebirr reference |
| `amount_etb` | FLOAT | Amount paid |
| `status` | ENUM | `pending` / `completed` / `failed` |

---

## ⚙️ Configuration Reference

| Variable | Required | Description |
|----------|----------|-------------|
| `TELEGRAM_BOT_TOKEN` | ✅ | From @BotFather |
| `ANTHROPIC_API_KEY` | ✅ | Claude Vision API key |
| `WEBHOOK_URL` | ✅ | Your deployed app URL |
| `DATABASE_URL` | ✅ | SQLite or PostgreSQL connection string |
| `TELEBIRR_APP_ID` | ⚠️ | Required for real payments |
| `TELEBIRR_APP_KEY` | ⚠️ | Required for real payments |
| `TELEBIRR_PUBLIC_KEY` | ⚠️ | RSA key for payload encryption |
| `TELEBIRR_SHORT_CODE` | ⚠️ | Merchant short code |
| `ADMIN_SECRET` | ✅ | Protects admin endpoints |
| `SUBSCRIPTION_PRICE_ETB` | — | Default: 199 |
| `FREE_TRIAL_SCANS` | — | Default: 3 |

---

## 🛡 Security Checklist

- [x] Webhook secret token validates all Telegram requests
- [x] Telebirr webhook signature verified before processing
- [x] Admin endpoints protected with secret header
- [x] All secrets loaded from environment variables
- [x] Non-root Docker user
- [x] Database connection uses connection pooling with pre-ping
- [x] Background task processing prevents webhook timeouts
- [x] Idempotent payment processing (double-payment safe)

---

## 📈 Scaling Notes

- **SQLite → PostgreSQL**: Change `DATABASE_URL` in `.env` — zero code changes needed
- **Workers**: Increase `--workers` in Dockerfile CMD (recommend: 2 × CPU cores)
- **Redis**: For high-volume bots, add Redis-based rate limiting per user_id
- **Celery**: Move AI analysis to background workers for better reliability

---

## 📞 Support

For Telebirr integration support: [developer.ethiotelecom.et](https://developer.ethiotelecom.et)  
For Claude API: [docs.anthropic.com](https://docs.anthropic.com)  
For Telegram Bot API: [core.telegram.org/bots](https://core.telegram.org/bots)
